package com.example.anli;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity implements OnClickListener {
    private static Context java;
    EditText edit, edit2;
    TextView zhu_ce,wang_ji ;
    private CheckBox cb_xieyi, cb_mima;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qq_deng_lu);
        //初始化方法
        initUI();
        jieshou();

    }

    private void initUI() {//点击方法
        findViewById(R.id.denglu_1).setOnClickListener(this);//登录
        edit = (EditText) findViewById(R.id.zhanghaokaung_1);//获取账号框id；
        edit2 = (EditText) findViewById(R.id.mimakuang_1);//密码框
        cb_mima=(CheckBox)findViewById(R.id.RadioButton_mima_1);//记住密码
        zhu_ce = (TextView) findViewById(R.id.deng_lu_text_zhu_ce);//登陆界面注册textview
        wang_ji = (TextView) findViewById(R.id.deng_lu_text_wang_ji);//忘记密码textview
        //TextView实现点击跳转
        zhu_ce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();//对象
                startActivity(intent.addCategory("zhu_ce_category").setAction("zhu_ce_action"));
            }
        });
        cb_mima.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Toast.makeText(MainActivity.this, "不是自己的设备不要点呦！！", Toast.LENGTH_SHORT).show();
            }
        });

    }
    private void jieshou(){
        //接收注册的号
        Bundle bundle1 = getIntent().getExtras();
//        String zhang_hao_ZC = bundle.getString("zhang_hao_ZC");
//        String mi_ma_ZC = bundle.getString("mi_ma_ZC");
        //赋值给登陆的号
//        edit.setText(bundle1.getString("zhang_hao_ZC"));//账号
//        edit2.setText(bundle1.getString("mi_ma_ZC"));

    }

    @Override//重写点击方法
    public void onClick(View v) {

        Intent intent = new Intent();//对象
        //传参。添加数据,先获取数据
        String zhang_hao = edit.getText().toString();//账号框获取得值
        String mi_ma = edit2.getText().toString();//密码框获取的值
        //搞一个容器一次传多个
        Bundle bd = new Bundle();
        bd.putString("zhang_hao", zhang_hao);
        bd.putString("mi_ma", mi_ma);
        intent.putExtras(bd);//purExtras一定要选Bundle类型否则报错
        switch (v.getId()) {//根据不同点击按钮实现intent，设置不同意图的类
            //登录按钮      //完成跳转得操作
            case R.id.denglu_1:// Intent intent = new Intent();
                startActivity(intent.addCategory("my_category").setAction("my_action"));
                //提示框
                Toast.makeText(getApplicationContext(), "登录成功", Toast.LENGTH_SHORT).show();
                break;
            //一键添加
//            case R.id.zhang_hao_kaung_zhu_ce:
////////                edit.setText("1742226589");
////////                edit2.setText("12645688");
//                startActivity(intent.addCategory("zhu_ce_category").setAction("zhu_ce_action"));
//               Toast.makeText(getApplicationContext(), "成功添加！", Toast.LENGTH_SHORT).show();
//              break;
////                 //退出



        }
    }

}





