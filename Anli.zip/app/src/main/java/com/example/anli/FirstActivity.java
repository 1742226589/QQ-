package com.example.anli;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class FirstActivity extends AppCompatActivity  {
    private Toolbar mToolbar;
    private BottomNavigationView mBottomNavigationView;

    private int lastIndex;
    List<Fragment> mFragments;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qq_zhu_jie_mian_xiao_xi);
        //获取第一个单选按钮，并设置其为选中状态
        //点击得方法
        jieshou3();

        initBottomNavigation();
        initData();

    }









    private void jieshou3() {
        //接收界面一得数据
        Bundle bundle = getIntent().getExtras();
        String zhang_hao = bundle.getString("zhang_hao");
        String mi_ma = bundle.getString("mi_ma");
        String zhang_hao_ZC = bundle.getString("zhang_hao_ZC");
        String mi_ma_ZC = bundle.getString("mi_ma_ZC");
    }
//导航栏操作
    public void initData() {

        mFragments = new ArrayList<>();
        mFragments.add(new tab_xiao_xi());
        mFragments.add(new tab_lain_xi_ren());
        mFragments.add(new tab_dong_tai());

        // 初始化展示MessageFragment
        setFragmentPosition(0);
    }

    public void initBottomNavigation() {
        mBottomNavigationView = findViewById(R.id.bv_bottomNavigation);
        // 解决当item大于三个时，非平均布局问题
        //BottomNavigationViewHelper.disableShiftMode(mBottomNavigationView);
        mBottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.tab_xiao_xi:
                        setFragmentPosition(0);
                        break;
                    case R.id.tab_lain_xi_ren:
                        setFragmentPosition(1);
                        break;
                    case R.id.tab_dong_tai:
                        setFragmentPosition(2);
                        break;

                    default:
                        break;
                }
                // 这里注意返回true,否则点击失效
                return true;
            }
        });
    }


    private void setFragmentPosition(int position) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        Fragment currentFragment = mFragments.get(position);
        Fragment lastFragment = mFragments.get(lastIndex);
        lastIndex = position;
        ft.hide(lastFragment);
        if (!currentFragment.isAdded()) {
            getSupportFragmentManager().beginTransaction().remove(currentFragment).commit();
            ft.add(R.id.ll_frameLayout, currentFragment);
        }
        ft.show(currentFragment);
        ft.commitAllowingStateLoss();
    }
}






