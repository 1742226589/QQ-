package com.example.anli;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class zhu_ce extends AppCompatActivity implements View.OnClickListener {
    EditText edit_z_h_zhu_ce, edie_m_m_zhu_ce;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qq_zhu_ce);
        zhuce();
    }

    private void zhuce() {
        findViewById(R.id.denglu_btn_zhu_ce).setOnClickListener(this);
        edit_z_h_zhu_ce = (EditText) findViewById(R.id.zhang_hao_kaung_zhu_ce);//注册的账号框
        edie_m_m_zhu_ce = (EditText) findViewById(R.id.mi_ma_kaung_zhu_ce);//注册的密码框
    }

    @Override
    public void onClick(View v) {
        Intent intent_zhu_ce = new Intent();//对象
        //传参。添加数据,先获取数据
        String zhang_hao_ZC = edit_z_h_zhu_ce.getText().toString();//账号框获取得值
        String mi_ma_ZC = edie_m_m_zhu_ce.getText().toString();//密码框获取的值
        //搞一个容器一次传多个
        Bundle bd = new Bundle();
        bd.putString("zhang_hao_ZC", zhang_hao_ZC);
        bd.putString("mi_ma_ZC", mi_ma_ZC);
        intent_zhu_ce.putExtras(bd);//purExtras一定要选Bundle类型否则报错

        switch (v.getId()) {//根据不同点击按钮实现intent，设置不同意图的类
            //登录按钮      //完成跳转得操作
            case R.id.denglu_btn_zhu_ce:// Intent intent = new Intent();
                //跳转
                startActivity(intent_zhu_ce.addCategory("my_category").setAction("my_action"));
                Toast.makeText(getApplicationContext(), "注册成功", Toast.LENGTH_SHORT).show();
                break;
        }
    }
}

